import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import pandas as pd

def send_excel_file():
    # Load the Excel file
    df = pd.read_excel('attendance_sheet.xlsx')

    # Set up the email
    msg = MIMEMultipart()
    msg['From'] = '422000351@ntc.edu.ph'
    msg['To'] = 'beagorospe332@gmail.com'
    msg['Subject'] = 'ATTENDANCE RECORD'

    # Attach the Excel file
    part = MIMEApplication(df.attendance_sheet(str(time.time()) + '.xlsx', engine='openpyxl'))
    part.add_header('Content-Disposition', 'attachment', filename='my_file.xlsx')
    msg.attach(part)

    # Send the email
    server = smtplib.SMTP('422000351@ntc.edu.ph')
    server.starttls()
    server.login('422000351@ntc.edu.ph', 'katkat88')
    server.sendmail('422000351@ntc.edu.ph', 'beagorospe332@gmail.com', msg.as_string())
    server.quit()